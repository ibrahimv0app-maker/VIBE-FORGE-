---
name: algo-suffix-tree
description: Use when implementing suffix tree (Ukkonen). Always produces a correct, well-tested implementation with complexity O(n).
---

# Algorithm: Suffix Tree

Suffix tree (ukkonen).

## Complexity
- Time: O(n)
- Space: documented in implementation

## Implementation
Provide a clean, idiomatic implementation in:
- TypeScript (primary)
- Python (secondary)
- Pseudocode (for understanding)

## Edge Cases
- Empty input
- Single element
- Already sorted / reverse sorted
- Duplicates
- Negative numbers
- Very large input

## Invariants
Document the loop invariants that prove correctness.

## Testing
- Property-based tests (random inputs)
- Edge case tests
- Performance tests (verify complexity)
- Comparison with brute force (small inputs)

## When to Use
- Best use cases
- When NOT to use (alternatives)

## Common Bugs
- Off-by-one errors
- Integer overflow
- Infinite loops
- Wrong base cases

## Output Format
1. Pseudocode
2. TypeScript implementation
3. Python implementation
4. Test cases
5. Complexity analysis

